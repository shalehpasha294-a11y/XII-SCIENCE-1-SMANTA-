export interface Student {
  id: string;
  name: string;
  photo: string;
}

export interface Photo {
  id: string;
  url: string;
  title: string;
  description: string;
}

export interface ClassData {
  className: string;
  students: Student[];
  moments: Photo[];
  teachers: {
    name: string;
    role: string;
    photo: string;
  }[];
}

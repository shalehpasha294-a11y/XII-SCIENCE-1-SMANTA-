import React from 'react';
import { Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black py-16 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto flex flex-col items-center">
        <div className="flex gap-8 mb-12">
          <a 
            href="https://www.instagram.com/unscien.one?igsh=MThlcWo3dnkxNnhybA==" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-white/40 hover:text-purple-500 transition-colors"
          >
            <Instagram size={24} />
          </a>
        </div>
        
        <div className="text-center">
          <p className="text-white/20 text-[10px] tracking-[0.4em] uppercase font-bold mb-4">
            © 2026 unscien.one | OPRSNproject. ALL RIGHTS RESERVED
          </p>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-8 bg-white/10" />
            <span className="text-white/40 font-mono text-[10px]">XII SCIENCE 1</span>
            <div className="h-px w-8 bg-white/10" />
          </div>
        </div>
      </div>
    </footer>
  );
}

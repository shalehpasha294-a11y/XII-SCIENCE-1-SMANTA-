import React from 'react';
import { motion } from 'motion/react';
import { classData } from '../data';

export default function Teachers() {
  return (
    <section id="teacher" className="py-24 bg-zinc-950 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <span className="text-purple-500 font-mono text-xs tracking-[0.3em] uppercase block mb-2">Our Mentors</span>
          <h2 className="text-white text-6xl font-black tracking-tighter">TEACHERS</h2>
        </div>

        <div className="flex flex-wrap justify-center gap-12 max-w-4xl mx-auto text-center">
          {classData.teachers.map((teacher, idx) => (
            <motion.div
              key={teacher.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="group w-full max-w-[400px]"
            >
              <div className="aspect-[4/5] overflow-hidden bg-zinc-900 mb-6 relative">
                <img
                  src={teacher.photo}
                  alt={teacher.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 border border-white/10 group-hover:border-purple-500/50 transition-colors duration-500" />
              </div>
              <h3 className="text-white text-2xl font-bold mb-1">{teacher.name}</h3>
              <p className="text-purple-500 font-mono text-xs uppercase tracking-widest">{teacher.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { Users, BookOpen, Camera, Trophy } from 'lucide-react';

export default function Stats() {
  const stats = [
    { label: 'Students', value: '35', icon: <Users size={20} /> },
    { label: 'Teachers', value: '65', icon: <BookOpen size={20} /> },
    { label: 'Years', value: '3', icon: <Trophy size={20} /> },
  ];

  return (
    <section className="py-24 bg-zinc-950 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex flex-col items-center text-center p-8 rounded-3xl bg-black/50 border border-white/5 hover:border-purple-500/30 transition-colors group"
            >
              <div className="w-12 h-12 rounded-xl bg-zinc-900 flex items-center justify-center text-purple-500 mb-6 group-hover:scale-110 transition-transform">
                {stat.icon}
              </div>
              <span className="text-4xl md:text-5xl font-black text-white tracking-tighter mb-2">{stat.value}</span>
              <span className="text-purple-500 font-mono text-[10px] uppercase tracking-[0.3em]">{stat.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

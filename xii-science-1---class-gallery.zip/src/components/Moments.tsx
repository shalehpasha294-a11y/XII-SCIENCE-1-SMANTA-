import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { classData } from '../data';
import { cn } from '../lib/utils';

interface MomentsProps {
  onPhotoClick: (index: number) => void;
}

interface MomentCardProps {
  photo: {
    id: string;
    url: string;
    title: string;
  };
  idx: number;
  startIndex: number;
  onPhotoClick: (index: number) => void;
  key?: string | number;
}

function MomentCard({ photo, idx, startIndex, onPhotoClick }: MomentCardProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3, delay: idx * 0.05 }}
      className="group relative aspect-[3/4] overflow-hidden bg-zinc-900 cursor-pointer"
      onClick={() => onPhotoClick(startIndex + idx)}
    >
      {!isLoaded && (
        <div className="absolute inset-0 bg-zinc-800 animate-pulse">
          <div className="w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
        </div>
      )}
      <img
        src={photo.url}
        alt={photo.title}
        onLoad={() => setIsLoaded(true)}
        className={cn(
          "w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110",
          !isLoaded ? "opacity-0" : "opacity-100"
        )}
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
        <button className="bg-purple-600 text-white text-[10px] font-bold tracking-[0.2em] px-6 py-3 rounded-full transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
          VIEW STORY
        </button>
      </div>
    </motion.div>
  );
}

export default function Moments({ onPhotoClick }: MomentsProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const photosPerPage = 10;
  
  const totalPages = Math.ceil(classData.moments.length / photosPerPage);
  const startIndex = (currentPage - 1) * photosPerPage;
  const currentPhotos = classData.moments.slice(startIndex, startIndex + photosPerPage);

  return (
    <section id="moments" className="py-24 bg-black px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <span className="text-purple-500 font-mono text-xs tracking-[0.3em] uppercase block mb-2">Our Memories</span>
            <h2 className="text-white text-6xl font-black tracking-tighter">MOMENTS</h2>
          </div>
          <div className="hidden md:block text-white/30 text-xs font-mono">
            {startIndex + 1} - {Math.min(startIndex + photosPerPage, classData.moments.length)} / {classData.moments.length}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <AnimatePresence mode="wait">
            {currentPhotos.map((photo, idx) => (
              <MomentCard 
                key={photo.id} 
                photo={photo} 
                idx={idx} 
                startIndex={startIndex} 
                onPhotoClick={onPhotoClick} 
              />
            ))}
          </AnimatePresence>
        </div>

        <div className="mt-12 flex justify-center items-center gap-4">
          <button
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-white transition-all"
          >
            <ChevronLeft size={20} />
          </button>
          
          <div className="flex gap-2">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i + 1)}
                className={cn(
                  "w-10 h-10 rounded-full text-xs font-bold transition-all",
                  currentPage === i + 1 
                    ? "bg-purple-600 text-white" 
                    : "text-white/40 hover:text-white border border-white/10"
                )}
              >
                {i + 1}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
            className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-white transition-all"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}

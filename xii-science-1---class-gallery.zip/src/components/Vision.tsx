import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export default function Vision() {
  return (
    <section className="py-32 bg-black relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0 opacity-30">
        <img
          src="https://lh3.googleusercontent.com/u/0/d/15lrzg6gglV8so9Fg0etvPN1ehX3MJdFF"
          alt="Vision Background"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black" />
      </div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center"
        >
          <div className="flex justify-center mb-12">
            <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-white/10 flex items-center justify-center text-purple-500">
              <Quote size={32} />
            </div>
          </div>

          <h2 className="text-white text-4xl md:text-6xl font-black tracking-tighter leading-tight mb-12 italic uppercase">
            "Satu Hati, Satu Solidaritas, <br /> 
            <span className="text-purple-500">Tanpa Batas</span>"
          </h2>

          <div className="grid md:grid-cols-3 gap-12 mt-20">
            {[
              { title: 'SOLIDARITY', desc: 'Kebersamaan adalah kunci utama dalam setiap langkah kami.' },
              { title: 'INTELLIGENCE', desc: 'Berpikir kritis dan inovatif untuk masa depan yang cerah.' },
              { title: 'LEGACY', desc: 'Meninggalkan jejak positif yang akan selalu dikenang.' },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
                className="flex flex-col items-center"
              >
                <span className="text-purple-500 font-mono text-xs tracking-[0.3em] uppercase mb-4">{item.title}</span>
                <p className="text-white/60 text-sm leading-relaxed max-w-[250px]">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { classData } from '../data';

export default function Marquee() {
  // Duplicate the list to ensure seamless looping
  const doubledStudents = [...classData.students, ...classData.students];

  return (
    <div className="bg-white py-12 overflow-hidden border-y border-black">
      <motion.div
        animate={{ x: [0, -2000] }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: "linear"
        }}
        className="flex whitespace-nowrap items-center gap-12"
      >
        {doubledStudents.map((student, idx) => (
          <div key={`${student.id}-${idx}`} className="flex items-center gap-12">
            <span className="text-black text-6xl md:text-8xl font-black tracking-tighter uppercase">
              {student.name}
            </span>
            <div className="w-4 h-4 rounded-full bg-purple-500" />
          </div>
        ))}
      </motion.div>
    </div>
  );
}

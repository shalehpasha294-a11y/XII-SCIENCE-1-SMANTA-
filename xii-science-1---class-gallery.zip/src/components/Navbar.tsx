import React, { useState, useEffect } from 'react';
import { cn } from '../lib/utils';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navLinks = [
    { name: 'HOME', id: 'home' },
    { name: 'TEACHER', id: 'teacher' },
    { name: 'STUDENTS', id: 'students' },
  ];

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 w-full z-50 transition-all duration-300 px-6 py-4 flex justify-between items-center',
        isScrolled ? 'bg-black/80 backdrop-blur-md py-3' : 'bg-transparent'
      )}
    >
      <div className="text-white font-bold text-xl tracking-tighter">
        XII<span className="text-purple-500">SCI</span>1
      </div>
      <div className="flex gap-8">
        {navLinks.map((link) => (
          <button
            key={link.id}
            onClick={() => scrollToSection(link.id)}
            className="text-white/70 hover:text-white text-xs font-bold tracking-widest transition-colors"
          >
            {link.name}
          </button>
        ))}
      </div>
    </nav>
  );
}

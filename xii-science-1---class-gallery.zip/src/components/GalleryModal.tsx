import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize2, Minimize2 } from 'lucide-react';
import { classData } from '../data';
import { cn } from '../lib/utils';

interface GalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialIndex: number;
}

export default function GalleryModal({ isOpen, onClose, initialIndex }: GalleryModalProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isZoomed, setIsZoomed] = useState(false);

  useEffect(() => {
    setCurrentIndex(initialIndex);
  }, [initialIndex]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      setIsZoomed(false);
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % classData.moments.length);
  }, []);

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + classData.moments.length) % classData.moments.length);
  }, []);

  const toggleZoom = () => setIsZoomed(!isZoomed);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleNext, handlePrev, onClose]);

  if (!isOpen) return null;

  const currentPhoto = classData.moments[currentIndex];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black flex flex-col"
      >
        {/* Header */}
        <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-center z-50 bg-gradient-to-b from-black/80 to-transparent">
          <div className="text-white font-mono text-sm tracking-widest">
            <span className="text-purple-500 font-bold">{currentIndex + 1}</span> / {classData.moments.length} {classData.className}
          </div>
          <div className="flex gap-6 items-center">
            <button 
              onClick={toggleZoom}
              className="text-white/70 hover:text-white transition-colors"
            >
              {isZoomed ? <X size={24} /> : <ZoomIn size={24} />}
            </button>
            <button 
              onClick={onClose}
              className="text-white/70 hover:text-white transition-colors"
            >
              <X size={28} />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 relative flex items-center justify-center overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
              className={cn(
                "w-full h-full flex items-center justify-center p-4 md:p-12 transition-transform duration-500",
                isZoomed ? "scale-150 cursor-zoom-out" : "scale-100 cursor-default"
              )}
              onClick={() => isZoomed && setIsZoomed(false)}
            >
              <img
                src={currentPhoto.url}
                alt={currentPhoto.title}
                className="max-w-full max-h-full object-contain shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </AnimatePresence>

          {/* Navigation Arrows */}
          <button
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            className="absolute left-6 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white transition-all z-50"
          >
            <ChevronLeft size={32} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            className="absolute right-6 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white transition-all z-50"
          >
            <ChevronRight size={32} />
          </button>
        </div>

        {/* Footer / Thumbnails */}
        <div className="w-full bg-zinc-950/80 backdrop-blur-md p-6 border-t border-white/5">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar justify-center">
              {classData.moments.map((photo, idx) => (
                <button
                  key={photo.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={cn(
                    "flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-all duration-300",
                    currentIndex === idx ? "border-purple-500 scale-110" : "border-transparent opacity-40 hover:opacity-100"
                  )}
                >
                  <img src={photo.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

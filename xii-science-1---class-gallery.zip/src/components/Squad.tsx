import React from 'react';
import { motion } from 'motion/react';
import { classData } from '../data';
import { cn } from '../lib/utils';

interface StudentCardProps {
  student: {
    id: string;
    name: string;
    photo: string;
  };
  idx: number;
  key?: string | number;
}

function StudentCard({ student, idx }: StudentCardProps) {
  const [isLoaded, setIsLoaded] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: (idx % 5) * 0.1 }}
      className="group cursor-default"
    >
      <div className="aspect-[3/4] overflow-hidden bg-zinc-900 mb-4 relative">
        {!isLoaded && (
          <div className="absolute inset-0 bg-zinc-800 animate-pulse">
            <div className="w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
          </div>
        )}
        <img
          src={student.photo}
          alt={student.name}
          onLoad={() => setIsLoaded(true)}
          className={cn(
            "w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105",
            !isLoaded ? "opacity-0" : "opacity-100"
          )}
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 border border-white/5 group-hover:border-purple-500/30 transition-colors duration-500" />
        <div className="absolute bottom-0 left-0 w-full p-3 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <span className="text-[10px] text-white/60 font-mono uppercase tracking-widest">Student {(idx + 1).toString().padStart(2, '0')}</span>
        </div>
      </div>
      <h3 className="text-white text-sm font-bold group-hover:text-purple-500 transition-colors uppercase tracking-tight leading-tight">
        {student.name}
      </h3>
    </motion.div>
  );
}

export default function Squad() {
  return (
    <section id="students" className="py-24 bg-black px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <span className="text-purple-500 font-mono text-xs tracking-[0.3em] uppercase block mb-2">The Squad</span>
          <h2 className="text-white text-6xl font-black tracking-tighter">STUDENTS</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-6 gap-y-10">
          {classData.students.map((student, idx) => (
            <StudentCard key={student.id} student={student} idx={idx} />
          ))}
        </div>
      </div>
    </section>
  );
}

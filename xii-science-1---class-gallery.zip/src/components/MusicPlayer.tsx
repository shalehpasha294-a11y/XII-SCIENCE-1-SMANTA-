import React, { useState, useRef, useEffect } from 'react';
import { Music, Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function MusicPlayer() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="fixed bottom-8 left-8 z-[60] flex items-end gap-3">
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, x: -20, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, x: 0, scale: 1, y: 0 }}
            exit={{ opacity: 0, x: -20, scale: 0.8, y: 20 }}
            className="bg-zinc-900/90 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden mb-2 w-[300px] h-[80px] md:w-[350px]"
          >
            <iframe 
              style={{ borderRadius: '12px' }}
              src="https://open.spotify.com/embed/track/5TReP8XK4aTOe2m44ZjQqz?utm_source=generator&theme=0" 
              width="100%" 
              height="80" 
              frameBorder="0" 
              allowFullScreen={true} 
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
              loading="lazy"
            ></iframe>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all duration-500 bg-zinc-900 border border-white/10 hover:border-purple-500/50`}
      >
        <Music className={`text-white transition-transform duration-500 ${isExpanded ? 'rotate-12 text-purple-500' : ''}`} size={24} />
      </motion.button>
    </div>
  );
}

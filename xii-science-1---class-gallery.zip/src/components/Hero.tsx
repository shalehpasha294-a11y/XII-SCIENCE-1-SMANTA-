import React from 'react';
import { motion } from 'motion/react';

export default function Hero() {
  return (
    <section id="home" className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-black">
      <div className="absolute inset-0 z-0">
        <img
          src="https://lh3.googleusercontent.com/u/0/d/1C03wnUYNJ3TPfmyY5Ffyk32XW5KNkdoX"
          alt="Class Hero"
          className="w-full h-full object-cover opacity-100"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-4"
        >
          <span className="text-purple-500 font-mono text-sm tracking-[0.3em] uppercase">The Legacy of</span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="text-white text-7xl md:text-9xl font-black tracking-tighter leading-none mb-8"
        >
          XII SCIENCE 1
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="flex flex-col items-center"
        >
          <div className="h-24 w-px bg-gradient-to-b from-purple-500 to-transparent mb-4" />
          <motion.h2 
            whileHover={{ scale: 1.1, letterSpacing: "0.2em" }}
            whileTap={{ scale: 0.95 }}
            className="text-white text-5xl md:text-7xl font-black tracking-widest text-outline cursor-default transition-all duration-300"
          >
            SAINS 1
          </motion.h2>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-white/30 text-[10px] tracking-[0.5em] uppercase">Scroll Down</span>
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-px h-12 bg-white/20"
        />
      </div>
    </section>
  );
}

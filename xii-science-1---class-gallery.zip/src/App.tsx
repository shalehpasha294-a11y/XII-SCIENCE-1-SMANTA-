/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Vision from './components/Vision';
import Marquee from './components/Marquee';
import Moments from './components/Moments';
import Teachers from './components/Teachers';
import Squad from './components/Squad';
import Stats from './components/Stats';
import Footer from './components/Footer';
import GalleryModal from './components/GalleryModal';
import PixelTrail from './components/PixelTrail';
import MusicPlayer from './components/MusicPlayer';
import ScrollToTop from './components/ScrollToTop';

export default function App() {
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);

  const openGallery = (index: number) => {
    setSelectedPhotoIndex(index);
    setIsGalleryOpen(true);
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-purple-500 selection:text-white">
      <PixelTrail />
      <Navbar />
      
      <main>
        <Hero />
        <Vision />
        <Teachers />
        <Marquee />
        <Squad />
        <Stats />
        <Moments onPhotoClick={openGallery} />
      </main>

      <Footer />
      <MusicPlayer />
      <ScrollToTop />

      <GalleryModal 
        isOpen={isGalleryOpen} 
        onClose={() => setIsGalleryOpen(false)} 
        initialIndex={selectedPhotoIndex} 
      />
    </div>
  );
}
